# News-scraper
This script scrape news from websites and publish it on your wordpress website using xml-rpc.<br>
Script is created by me in January 2018 year, and it is used by me for my news portal.
